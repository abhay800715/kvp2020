const express = require('express');
const router = express.Router();
const Lead = require('../models/Lead');
const nodemailer = require('nodemailer');

router.post('/', async (req, res) => {
  const { fullName, mobileNumber, email, city, propertyType, budgetRange, message } = req.body;

  const mobileRegex = /^[6-9]\d{9}$/;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!fullName || !mobileNumber || !email || !city || !propertyType || !budgetRange || !message) {
    return res.status(400).json({ msg: 'Please fill all fields' });
  }

  if (!mobileRegex.test(mobileNumber)) {
    return res.status(400).json({ msg: 'Invalid Indian mobile number' });
  }

  if (!emailRegex.test(email)) {
    return res.status(400).json({ msg: 'Invalid email address' });
  }

  try {
    const newLead = new Lead({
      fullName,
      mobileNumber,
      email,
      city,
      propertyType,
      budgetRange,
      message
    });

    await newLead.save();

    if (process.env.SMTP_HOST) {
      let transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: process.env.SMTP_PORT,
        secure: false,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        }
      });

      await transporter.sendMail({
        from: `"AI Realty" <${process.env.SMTP_USER}>`,
        to: email,
        subject: 'Thank you for registering your interest!',
        text: `Dear ${fullName},\n\nThank you for your interest in our real estate services. We will contact you soon!\n\nRegards,\nAI Realty`
      });
    }

    res.status(201).json({ msg: 'Lead saved successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

router.get('/analytics', async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0,0,0,0);

    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    const todayCount = await Lead.countDocuments({ createdAt: { $gte: today } });
    const weekCount = await Lead.countDocuments({ createdAt: { $gte: weekAgo } });
    const totalCount = await Lead.countDocuments();

    res.json({ todayCount, weekCount, totalCount });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;