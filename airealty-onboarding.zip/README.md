# AI Realty - Customer Onboarding

## Setup Instructions

- Clone the repo
- Copy `.env.example` to `.env` for both backend and frontend
- Install dependencies
- Run backend: `npm run dev`
- Run frontend: `npm start`