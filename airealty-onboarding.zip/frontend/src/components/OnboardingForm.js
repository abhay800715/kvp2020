import React, { useState } from 'react';

const OnboardingForm = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    mobileNumber: '',
    email: '',
    city: '',
    propertyType: '',
    budgetRange: '',
    message: ''
  });

  const [status, setStatus] = useState('');

  const handleChange = e => {
    setFormData({...formData, [e.target.name]: e.target.value});
  };

  const validate = () => {
    const mobileRegex = /^[6-9]\d{9}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (Object.values(formData).some(v => v.trim() === '')) {
      return 'All fields are required.';
    }
    if (!mobileRegex.test(formData.mobileNumber)) {
      return 'Invalid Indian mobile number.';
    }
    if (!emailRegex.test(formData.email)) {
      return 'Invalid email address.';
    }
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const error = validate();
    if (error) {
      setStatus(error);
      return;
    }

    try {
      const res = await fetch('http://localhost:5000/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await res.json();

      if (!res.ok) throw new Error(data.msg);

      setStatus('Form submitted successfully!');
      setFormData({
        fullName: '',
        mobileNumber: '',
        email: '',
        city: '',
        propertyType: '',
        budgetRange: '',
        message: ''
      });
    } catch (err) {
      setStatus(err.message);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="fullName" placeholder="Full Name" value={formData.fullName} onChange={handleChange} />
      <input name="mobileNumber" placeholder="Mobile Number" value={formData.mobileNumber} onChange={handleChange} />
      <input name="email" placeholder="Email Address" value={formData.email} onChange={handleChange} />
      <input name="city" placeholder="City of Interest" value={formData.city} onChange={handleChange} />
      <select name="propertyType" value={formData.propertyType} onChange={handleChange}>
        <option value="">Select Property Type</option>
        <option value="Apartment">Apartment</option>
        <option value="Plot">Plot</option>
        <option value="Commercial">Commercial</option>
        <option value="Villa">Villa</option>
        <option value="Farmhouse">Farmhouse</option>
      </select>
      <input name="budgetRange" placeholder="Budget Range" value={formData.budgetRange} onChange={handleChange} />
      <textarea name="message" placeholder="Message / Comments" value={formData.message} onChange={handleChange} />
      <button type="submit">Submit</button>
      <p>{status}</p>
    </form>
  );
};

export default OnboardingForm;