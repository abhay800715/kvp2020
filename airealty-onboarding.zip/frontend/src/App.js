import React from 'react';
import OnboardingForm from './components/OnboardingForm';

function App() {
  return (
    <div className="App">
      <h1>AI Realty - Register Your Interest</h1>
      <OnboardingForm />
    </div>
  );
}

export default App;